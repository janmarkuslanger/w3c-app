/**
 * list group
 * @type {HTML Element}
 */
export const listGroup = document.querySelector('.pane-sm.sidebar .list-group');
