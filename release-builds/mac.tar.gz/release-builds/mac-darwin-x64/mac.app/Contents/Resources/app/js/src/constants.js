export const githubUrl = 'https://github.com/janmarkuslanger/w3c-app';
